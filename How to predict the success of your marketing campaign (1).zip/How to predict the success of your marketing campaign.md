```python
import pandas as pd
data =pd.read_csv(r"impressions (1).csv")
data.shape

```




    (241, 13)




```python
data.columns
```




    Index(['impressions', 'budget', 'start_month', 'end_month', 'start_week',
           'end_week', 'days', 'region', 'category', 'facebook', 'instagram',
           'google_search', 'google_display'],
          dtype='object')




```python
data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>impressions</th>
      <th>budget</th>
      <th>start_month</th>
      <th>end_month</th>
      <th>start_week</th>
      <th>end_week</th>
      <th>days</th>
      <th>region</th>
      <th>category</th>
      <th>facebook</th>
      <th>instagram</th>
      <th>google_search</th>
      <th>google_display</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9586</td>
      <td>600</td>
      <td>7</td>
      <td>8</td>
      <td>29</td>
      <td>31</td>
      <td>14</td>
      <td>germany</td>
      <td>other</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10678</td>
      <td>100</td>
      <td>2</td>
      <td>2</td>
      <td>6</td>
      <td>8</td>
      <td>15</td>
      <td>germany</td>
      <td>comedy</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18277</td>
      <td>100</td>
      <td>8</td>
      <td>9</td>
      <td>34</td>
      <td>39</td>
      <td>37</td>
      <td>germany</td>
      <td>concert</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>18446</td>
      <td>100</td>
      <td>2</td>
      <td>3</td>
      <td>7</td>
      <td>10</td>
      <td>21</td>
      <td>switzerland</td>
      <td>NaN</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>19691</td>
      <td>100</td>
      <td>2</td>
      <td>3</td>
      <td>7</td>
      <td>10</td>
      <td>22</td>
      <td>switzerland</td>
      <td>NaN</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>20573</td>
      <td>200</td>
      <td>7</td>
      <td>7</td>
      <td>28</td>
      <td>29</td>
      <td>8</td>
      <td>germany</td>
      <td>comedy</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>23139</td>
      <td>300</td>
      <td>6</td>
      <td>7</td>
      <td>24</td>
      <td>27</td>
      <td>23</td>
      <td>germany</td>
      <td>conference</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>25000</td>
      <td>200</td>
      <td>4</td>
      <td>5</td>
      <td>17</td>
      <td>20</td>
      <td>21</td>
      <td>germany</td>
      <td>concert</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>25017</td>
      <td>100</td>
      <td>2</td>
      <td>4</td>
      <td>9</td>
      <td>15</td>
      <td>44</td>
      <td>germany</td>
      <td>festival</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>25062</td>
      <td>100</td>
      <td>10</td>
      <td>12</td>
      <td>43</td>
      <td>51</td>
      <td>56</td>
      <td>germany</td>
      <td>concert</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
import seaborn as sns
quan = list(data.loc[:, data.dtypes != 'object'].columns.values)
grid = sns.FacetGrid(pd.melt(data, value_vars=quan),
                     col='variable', col_wrap=4, height=3, aspect=1,
                     sharex=False, sharey=False)
grid.map(plt.hist, 'value', color="steelblue")
plt.show()
```


![png](output_3_0.png)



```python
sns.heatmap(data._get_numeric_data().astype(float).corr(),
            square=True, cmap='RdBu_r', linewidths=.5,
            annot=True, fmt='.2f').figure.tight_layout()
plt.show()

```


![png](output_4_0.png)



```python
data.corr(method='pearson').iloc[0].sort_values(ascending=False)
```




    impressions       1.000000
    budget            0.556317
    days              0.449491
    google_display    0.269616
    google_search     0.164593
    instagram         0.073916
    start_month       0.039573
    start_week        0.029295
    end_month         0.014446
    end_week          0.012436
    facebook         -0.382057
    Name: impressions, dtype: float64




```python

```
